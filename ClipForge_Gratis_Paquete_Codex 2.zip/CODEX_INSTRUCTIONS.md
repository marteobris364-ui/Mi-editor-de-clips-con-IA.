# Instrucciones para Codex

Trabaja sobre este repositorio y conviértelo en un editor de clips funcional, sin pagos obligatorios ni APIs comerciales.

## Orden de trabajo
1. Ejecuta `npm install` y `npm run build`; corrige errores.
2. Revisa la integración FFmpeg.wasm y prueba exportar un clip de 5–10 segundos.
3. Implementa ASR local opcional (Whisper.cpp o Transformers.js) con timestamps reales. No uses timestamps estimados para subtítulos sincronizados.
4. Integra VAD (por ejemplo Silero VAD en una implementación compatible con browser) para marcar silencios. Permite revisar antes de cortar.
5. Añade detección de escenas (histogramas/cambios de frame) y puntuación explicable de highlights; no prometas viralidad.
6. Crea una arquitectura de workers para evitar bloquear la interfaz.
7. Añade pruebas y documenta el tamaño de modelos, compatibilidad, límites de iPhone y descarga.
8. No descargues videos desde plataformas que no permitan hacerlo; enlaces externos pueden abrirse, no extraerse automáticamente.

## Regla de gratuidad
No usar endpoints de pago, suscripciones, créditos, bases de datos pagadas ni backend obligatorio. Preferir procesamiento local y hosting estático. Si una función necesita hardware, indicar el requisito y ofrecer alternativa.
