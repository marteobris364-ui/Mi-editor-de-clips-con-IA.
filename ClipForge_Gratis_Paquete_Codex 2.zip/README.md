# ClipForge Gratis — proyecto base para Codex

Aplicación web local para seleccionar, recortar y exportar clips. No usa API de pago ni backend obligatorio.

## Requisitos
- Node.js 20+ (en computadora)
- npm
- Navegador moderno
- Para videos grandes, preferir computadora: FFmpeg.wasm consume mucha memoria.

## Ejecutar
```bash
npm install
npm run dev
```
Abre la URL que Vite muestra.

## Compilar
```bash
npm run build
npm run preview
```

## Funciones incluidas
- Importar video local.
- Vista previa.
- Selección manual de inicio/fin.
- Exportación MP4 usando FFmpeg.wasm (carga el motor desde CDN público; no es API de pago, pero requiere internet).
- Editor de segmentos de texto y exportación/importación SRT.
- Puntuación orientativa de frases/segmentos (no garantiza viralidad).

## Límites honestos
- ASR/Whisper no viene descargado: los modelos pesan mucho. Codex debe integrar una opción local de ASR (Whisper.cpp o Transformers.js) y explicar descarga, tamaño y rendimiento.
- Comprensión semántica audiovisual avanzada requiere modelo multimodal local potente o servicio remoto; no se promete en esta versión.
- Enlaces de YouTube/TikTok/Instagram no se descargan automáticamente. Importa archivos propios o fuentes permitidas. Respetar derechos, términos y restricciones.
- La web estática no mantiene un servidor de procesamiento. Todo el procesamiento de video se hace en el navegador.
- GitHub Pages/Cloudflare Pages alojan frontend estático gratuitamente dentro de sus límites; no ejecutan backend ni modelos pesados en servidor.

## Publicación gratuita
1. Sube el contenido del ZIP a un repositorio GitHub.
2. GitHub → Settings → Pages → Build and deployment → GitHub Actions (o usa Cloudflare Pages).
3. Para Vite en GitHub Pages, configurar `base` con el nombre del repositorio antes del build.
4. No añadas claves secretas al frontend.

## Próxima etapa en Codex
Lee `CODEX_INSTRUCTIONS.md` y continúa implementando ASR real con timestamps, VAD, extracción de escenas y tests. No declares una función lista si no está implementada.
