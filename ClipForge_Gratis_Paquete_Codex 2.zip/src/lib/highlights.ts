// Heurística sencilla: puntúa longitud, preguntas, números y palabras de impacto. No predice viralidad.
const hooks=['increíble','nunca','secreto','descubre','error','verdad','por qué','cómo','antes','después','sorpresa','pero'];
export function scoreText(text:string){const t=text.toLowerCase();let score=Math.min(30,text.length/8);score+=hooks.reduce((n,w)=>n+(t.includes(w)?8:0),0);score+=(text.match(/[!?]/g)||[]).length*3;score+=(text.match(/\d+/g)||[]).length*4;return Math.min(100,Math.round(score))}
